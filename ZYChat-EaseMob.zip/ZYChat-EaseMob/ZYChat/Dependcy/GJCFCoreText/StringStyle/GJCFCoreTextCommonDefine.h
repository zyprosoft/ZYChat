//
//  GJCFCoreTextCommonDefine.h
//  GJCommonFoundation
//
//  Created by ZYVincent on 14-9-27.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * const kGJCFCoreTextKeywordBackgroundColorAttributedName;

extern NSString * const kGJCFCoreTextKeywordBackgroundCornerRadiusAttributedName;

@interface GJCFCoreTextCommonDefine : NSObject

@end
