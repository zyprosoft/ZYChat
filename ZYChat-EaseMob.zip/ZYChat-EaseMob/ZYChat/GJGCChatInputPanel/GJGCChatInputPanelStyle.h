//
//  GJGCChatInputPanelStyle.h
//  GJGCChatInputPanel
//
//  Created by ZYVincent on 15/7/10.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GJGCChatInputPanelStyle : NSObject

+ (UIColor *)mainSeprateLineColor;

+ (UIColor *)mainThemeColor;

+ (UIColor *)mainBackgroundColor;

+ (UIColor *)baseAndTitleAssociateTextColor;


@end
