//
//  GJGCChatInputExpandMenuPanelConfigModel.m
//  ZYChat
//
//  Created by ZYVincent on 15/4/21.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import "GJGCChatInputExpandMenuPanelConfigModel.h"

@implementation GJGCChatInputExpandMenuPanelConfigModel

@end
