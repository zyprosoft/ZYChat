//
//  GJGCIconSeprateImageView.h
//  ZYChat
//
//  Created by ZYVincent on 14-12-16.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJGCIconSeprateImageView : UIView

@property (nonatomic,strong)UIImage *image;

@end
