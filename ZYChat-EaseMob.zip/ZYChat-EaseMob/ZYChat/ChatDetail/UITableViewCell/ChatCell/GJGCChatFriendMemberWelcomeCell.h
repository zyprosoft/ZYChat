//
//  GJGCChatFriendMemberWelcomeCell.h
//  ZYChat
//
//  Created by ZYVincent on 15-3-18.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import "GJGCChatFriendBaseCell.h"

@interface GJGCChatFriendMemberWelcomeCell : GJGCChatFriendBaseCell

@end
