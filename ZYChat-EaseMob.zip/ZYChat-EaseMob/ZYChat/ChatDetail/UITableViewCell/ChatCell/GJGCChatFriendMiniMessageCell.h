//
//  GJGCChatFriendMiniMessageCell.h
//  ZYChat
//
//  Created by ZYVincent on 14-12-8.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import "GJGCChatFriendBaseCell.h"

@interface GJGCChatFriendMiniMessageCell : GJGCChatBaseCell

@end
