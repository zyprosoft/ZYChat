//
//  GJGCChatSystemNotiRoleGroupView.h
//  ZYChat
//
//  Created by ZYVincent on 14-11-3.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GJGCLevelView.h"

@interface GJGCChatSystemNotiRoleGroupView : UIView

@property (nonatomic,strong)NSAttributedString *level;

@property (nonatomic,strong)NSAttributedString *memberCount;



@end
