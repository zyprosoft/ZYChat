//
//  GJGCDriftBottleImageScrollView.h
//  ZYChat
//
//  Created by ZYVincent on 15/7/1.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJGCDriftBottleImageScrollView : UIScrollView

- (UIImage *)contentImage;

- (void)setNeedShowImage:(UIImage *)aImage;

@end
