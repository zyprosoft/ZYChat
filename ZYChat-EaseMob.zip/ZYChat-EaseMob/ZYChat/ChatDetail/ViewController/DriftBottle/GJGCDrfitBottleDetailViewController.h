//
//  GJGCDrfitBottleDetailViewController.h
//  ZYChat
//
//  Created by ZYVincent on 15/7/1.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import "GJGCBaseViewController.h"

@interface GJGCDrfitBottleDetailViewController : GJGCBaseViewController

- (instancetype)initWithThumbImage:(UIImage *)aImage withImageUrl:(NSString *)aImageUrl withContentString:(NSString *)aString;

@end
