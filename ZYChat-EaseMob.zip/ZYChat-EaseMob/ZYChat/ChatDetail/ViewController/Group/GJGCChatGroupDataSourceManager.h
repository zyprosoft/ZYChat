//
//  GJGCChatGroupDataSourceManager.h
//  ZYChat
//
//  Created by ZYVincent on 14-11-29.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import "GJGCChatDetailDataSourceManager.h"
#import "GJGCChatFriendTalkModel.h"

@interface GJGCChatGroupDataSourceManager : GJGCChatDetailDataSourceManager

@end
