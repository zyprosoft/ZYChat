//
//  ZYLoginViewController.h
//  ZYChat
//
//  Created by ZYVincent on 15/11/9.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GJGCBaseViewController.h"

@interface ZYLoginViewController : GJGCBaseViewController

@end
