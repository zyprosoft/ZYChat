//
//  GJGCRecentChatViewController.h
//  ZYChat
//
//  Created by ZYVincent on 15/7/11.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import "GJGCBaseViewController.h"

@interface GJGCRecentChatViewController : GJGCBaseViewController

@end
