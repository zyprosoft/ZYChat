//
//  GJGCRecentChatModel.m
//  ZYChat
//
//  Created by ZYVincent on 15/7/11.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import "GJGCRecentChatModel.h"

@implementation GJGCRecentChatModel


@end
