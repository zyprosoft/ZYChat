//
//  GJGCRecentChatCell.h
//  ZYChat
//
//  Created by ZYVincent on 15/7/11.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GJGCRecentChatModel.h"

@interface GJGCRecentChatCell : UITableViewCell

- (void)setContentModel:(GJGCRecentChatModel *)contentModel;

@end
